## W = 1

### Name : inst_100_50_100_50_75_25_45_01_2
- Upper Orig : 60244 (optimum)
- Lower Orig : 59167
- Gap Orig : 1.8
- Upper Relax : 66078 (optimum)
- Relax in Original : 59891.0
- Gap in Original : 0.6

### Name : inst_100_50_100_50_75_25_45_01_7
- Upper Orig : 52563 (optimum)
- Lower Orig : 50858
- Gap Orig : 3.10
- Upper Relax : 60090 (optimum)
- Relax in Original : 51563
- Gap in Original : 1.9

### Name : inst_100_50_100_50_75_25_45_01_12
- Upper Orig : 53101 (optimum)
- Lower Orig : 50867
- Gap Orig : 4.10
- Upper Relax : 60090 (optimum)
- Relax in Original : 51563
- Gap in Original : 2.8

### Name : inst_100_50_100_50_75_25_45_01_25
- Upper Orig : 53283 (optimum)
- Lower Orig : 50867
- Gap Orig : 4.50
- Upper Relax : 60090 (optimum)
- Relax in Original : 51563
- Gap in Original :3.2


### Name : inst_100_50_100_50_75_25_45_09_2
- Upper Orig : 50915 (optimum)
- Lower Orig : 46290
- Gap Orig : 4.10
- Upper Relax : 55225 (optimum)
- Relax in Original : 49081
- Gap in Original : 3.6

