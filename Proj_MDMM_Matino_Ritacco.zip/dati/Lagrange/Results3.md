## W = 0.4

### Name : inst_100_50_100_50_75_25_45_09_7
- Upper Orig : 45635 (optimum)
- Lower Orig : 45329
- Gap Orig : 0.50
- Upper Relax : 49092 (optimum)
- Relax in Original : 45482
- Gap in Original : 0.3

### Name : inst_100_50_100_50_75_25_45_09_12
- Upper Orig : 45635 (optimum)
- Lower Orig : 45329
- Gap Orig : 0.50
- Upper Relax : 49092 (optimum)
- Relax in Original : 45482
- Gap in Original : 0.3

### Name : inst_100_50_100_50_75_25_45_09_25
- Upper Orig : 45635 (optimum)
- Lower Orig : 45329
- Gap Orig : 0.50
- Upper Relax : 49092 (optimum)
- Relax in Original : 45482
- Gap in Original : 0.3