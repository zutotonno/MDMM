## W = 0.4

### Name : inst_100_50_100_50_75_25_45_05_7
- Upper Orig : 52700 (optimum)
- Lower Orig : 52229
- Gap Orig : 0.9
- Upper Relax : 56962 (optimum)
- Relax in Original : 52306
- Gap in Original : 0.7

### Name : inst_100_50_100_50_75_25_45_05_12
- Upper Orig : 52925 (optimum)
- Lower Orig : 52233
- Gap Orig : 1.30
- Upper Relax : 56962 (optimum)
- Relax in Original : 52306
- Gap in Original : 1.10

### Name : inst_100_50_100_50_75_25_45_05_25
- Upper Orig : 52925 (optimum)
- Lower Orig : 52233
- Gap Orig : 1.30
- Upper Relax : 56962 (optimum)
- Relax in Original : 52306
- Gap in Original : 1.10

